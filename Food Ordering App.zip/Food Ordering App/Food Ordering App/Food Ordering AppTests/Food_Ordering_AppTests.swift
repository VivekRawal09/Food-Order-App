//
//  Food_Ordering_AppTests.swift
//  Food Ordering AppTests
//
//  Created by Vivek Rawal on 20/04/25.
//

import Testing

struct Food_Ordering_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
