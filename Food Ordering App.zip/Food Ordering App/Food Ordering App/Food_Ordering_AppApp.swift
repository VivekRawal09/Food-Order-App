//
//  Food_Ordering_AppApp.swift
//  Food Ordering App
//
//  Created by Vivek Rawal on 20/04/25.
//

import SwiftUI

@main
struct Food_Ordering_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
