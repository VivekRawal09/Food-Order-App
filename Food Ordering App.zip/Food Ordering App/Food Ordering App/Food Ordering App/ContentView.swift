import SwiftUI

// MARK: - Data Models
struct MenuItem: Identifiable, Codable {
    let id: Int
    let name: String
    let price: Double
    let category: String
}

struct UserData: Codable {
    var firstName: String
    var lastName: String
    var email: String
}

// MARK: - Main App
@main
struct LittleLemonApp: App {
    @StateObject private var userDataManager = UserDataManager()
    
    var body: some Scene {
        WindowGroup {
            if userDataManager.hasOnboarded {
                HomeScreen()
                    .environmentObject(userDataManager)
            } else {
                OnboardingView()
                    .environmentObject(userDataManager)
            }
        }
    }
}

// MARK: - User Data Manager
class UserDataManager: ObservableObject {
    @Published var userData = UserData(firstName: "", lastName: "", email: "")
    @Published var hasOnboarded: Bool {
        didSet { UserDefaults.standard.set(hasOnboarded, forKey: "hasOnboarded") }
    }
    
    init() {
        self.hasOnboarded = UserDefaults.standard.bool(forKey: "hasOnboarded")
        if let savedData = UserDefaults.standard.data(forKey: "userData"),
           let decodedData = try? JSONDecoder().decode(UserData.self, from: savedData) {
            self.userData = decodedData
        }
    }
    
    func saveUserData() {
        if let encoded = try? JSONEncoder().encode(userData) {
            UserDefaults.standard.set(encoded, forKey: "userData")
            hasOnboarded = true
        }
    }
    
    func clearUserData() {
        UserDefaults.standard.removeObject(forKey: "userData")
        hasOnboarded = false
    }
}

// MARK: - Onboarding Screens
struct OnboardingView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        TabView {
            VStack {
                Text("Welcome to Little Lemon")
                NavigationLink("Next", destination: OnboardingPage2())
            }
            .tag(0)
            
            OnboardingPage2()
                .tag(1)
            
            OnboardingPage3()
                .tag(2)
        }
        .tabViewStyle(.page)
    }
}

struct OnboardingPage2: View {
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        VStack {
            TextField("First Name", text: $userDataManager.userData.firstName)
            TextField("Last Name", text: $userDataManager.userData.lastName)
            NavigationLink("Next", destination: OnboardingPage3())
        }
        .padding()
    }
}

struct OnboardingPage3: View {
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        VStack {
            TextField("Email", text: $userDataManager.userData.email)
            Button("Get Started") {
                userDataManager.saveUserData()
            }
        }
        .padding()
    }
}

// MARK: - Home Screen
struct HomeScreen: View {
    @EnvironmentObject var userDataManager: UserDataManager
    @State private var searchText = ""
    @State private var selectedCategory = "All"
    
    let menuItems = [
        MenuItem(id: 1, name: "Greek Salad", price: 12.99, category: "starters"),
        MenuItem(id: 2, name: "Bruschetta", price: 7.99, category: "starters"),
        MenuItem(id: 3, name: "Grilled Fish", price: 20.00, category: "mains")
    ]
    
    var filteredItems: [MenuItem] {
        menuItems.filter { item in
            (selectedCategory == "All" || item.category == selectedCategory.lowercased()) &&
            (searchText.isEmpty || item.name.localizedCaseInsensitiveContains(searchText))
        }
    }
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Header
                    HStack {
                        Text("Little Lemon")
                        Spacer()
                        NavigationLink(destination: ProfileView()) {
                            Image(systemName: "person.circle")
                        }
                    }
                    .padding()
                    
                    // Hero
                    VStack {
                        Text("Chicago • Mediterranean • $$$")
                        Text("Description...")
                        TextField("Search...", text: $searchText)
                    }
                    .padding()
                    .background(Color.green.opacity(0.2))
                    
                    // Categories
                    ScrollView(.horizontal) {
                        HStack {
                            ForEach(["All", "Starters", "Mains"], id: \.self) { category in
                                Button(category) { selectedCategory = category }
                            }
                        }
                    }
                    
                    // Menu List
                    ForEach(filteredItems) { item in
                        HStack {
                            Text(item.name)
                            Spacer()
                            Text("$\(item.price, specifier: "%.2f")")
                        }
                        .padding()
                    }
                }
            }
        }
    }
}

// MARK: - Profile Screen
struct ProfileView: View {
    @EnvironmentObject var userDataManager: UserDataManager
    
    var body: some View {
        VStack {
            Text("Profile")
            TextField("First Name", text: $userDataManager.userData.firstName)
            TextField("Last Name", text: $userDataManager.userData.lastName)
            TextField("Email", text: $userDataManager.userData.email)
            
            Button("Save Changes") {
                userDataManager.saveUserData()
            }
            
            Button("Log Out") {
                userDataManager.clearUserData()
            }
        }
        .padding()
    }
}
